// =============================================================
// desafios.ts — Desafios semanais (4 semanas x 5 tarefas)
// =============================================================

export interface Tarefa {
  id: string;
  texto: string;
}

export interface Semana {
  id: number;
  titulo: string;
  emoji: string;
  descricao: string;
  tarefas: Tarefa[];
}

export const semanas: Semana[] = [
  {
    id: 1,
    titulo: 'Mapeie a geladeira',
    emoji: '🧊',
    descricao:
      'Nesta semana, você vai conhecer o que tem na sua geladeira e descobrir o que está sendo desperdiçado.',
    tarefas: [
      { id: 's1t1', texto: 'Tire tudo da geladeira e veja o que tem guardado' },
      { id: 's1t2', texto: 'Separe o que está bom do que está vencido ou estragado' },
      { id: 's1t3', texto: 'Organize os produtos por data de validade' },
      { id: 's1t4', texto: 'Anote o que foi jogado fora e por quê' },
      { id: 's1t5', texto: 'Defina um lugar fixo para cada tipo de alimento' },
    ],
  },
  {
    id: 2,
    titulo: 'Aproveite cascas e talos',
    emoji: '🥕',
    descricao:
      'Vamos usar partes dos alimentos que normalmente vão para o lixo e descobrir novos sabores.',
    tarefas: [
      { id: 's2t1', texto: 'Pesquise uma receita com cascas ou talos' },
      { id: 's2t2', texto: 'Prepare a receita escolhida' },
      { id: 's2t3', texto: 'Prove com a família ou amigos e veja a opinião' },
      { id: 's2t4', texto: 'Guarde a receita que deu certo' },
      { id: 's2t5', texto: 'Compartilhe a experiência com alguém' },
    ],
  },
  {
    id: 3,
    titulo: 'Planeje o cardápio',
    emoji: '📝',
    descricao:
      'Planejar o que comer antes de comprar evita excessos e reduz o que sobra no final da semana.',
    tarefas: [
      { id: 's3t1', texto: 'Anote o que você e sua família gostam de comer' },
      { id: 's3t2', texto: 'Monte um cardápio para os próximos 5 dias' },
      { id: 's3t3', texto: 'Faça uma lista de compras baseada no cardápio' },
      { id: 's3t4', texto: 'Compre apenas o que está na lista' },
      { id: 's3t5', texto: 'Avalie no fim da semana: sobrou menos?' },
    ],
  },
  {
    id: 4,
    titulo: 'Compartilhe com a vizinhança',
    emoji: '🤝',
    descricao:
      'Desperdício zero é um trabalho em conjunto. Vamos espalhar a ideia pelo bairro.',
    tarefas: [
      { id: 's4t1', texto: 'Converse com um vizinho sobre o tema' },
      { id: 's4t2', texto: 'Compartilhe uma dica que funcionou para você' },
      { id: 's4t3', texto: 'Ofereça algo que está sobrando em casa' },
      { id: 's4t4', texto: 'Proponha uma ação coletiva (feira de troca ou mutirão)' },
      { id: 's4t5', texto: 'Celebre os resultados com o grupo' },
    ],
  },
];

export interface Selo {
  semanaId: number;
  nome: string;
  emoji: string;
  descricao: string;
}

export const selos: Selo[] = [
  {
    semanaId: 1,
    nome: 'Detetive da Geladeira',
    emoji: '🔍',
    descricao: 'Mapeou tudo o que tinha na geladeira e organizou do jeito certo.',
  },
  {
    semanaId: 2,
    nome: 'Mestre do Aproveitamento',
    emoji: '👩‍🍳',
    descricao: 'Transformou cascas e talos em pratos saborosos.',
  },
  {
    semanaId: 3,
    nome: 'Planejador de Cardápio',
    emoji: '📋',
    descricao: 'Planejou as refeições e comprou com consciência.',
  },
  {
    semanaId: 4,
    nome: 'Embaixador do Bairro',
    emoji: '🌟',
    descricao: 'Espalhou a ideia e mobilizou a comunidade.',
  },
];
