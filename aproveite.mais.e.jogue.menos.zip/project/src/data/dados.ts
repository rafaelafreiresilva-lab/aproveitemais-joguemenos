// =============================================================
// dados.ts — Dados e estatísticas sobre desperdício de alimentos
// ATENÇÃO: Verifique e atualize estes números com as fontes oficiais.
// Última verificação: outubro 2024.
// =============================================================

export interface DadoImpacto {
  numero: string;
  descricao: string;
  fonte: string;
  ano: string;
}

export interface DadoCard {
  valor: string;
  titulo: string;
  descricao: string;
  fonte: string;
}

// Números de impacto (faixa animada na home)
export const dadosImpacto: DadoImpacto[] = [
  {
    numero: '33',
    descricao: 'da comida produzida no mundo é perdida ou desperdiçada',
    fonte: 'FAO',
    ano: '2019',
  },
  {
    numero: '1050',
    descricao: 'milhões de toneladas desperdiçadas no mundo em 2022',
    fonte: 'PNUMA/ONU — Food Waste Index 2024',
    ano: '2024',
  },
  {
    numero: '60',
    descricao: 'do desperdício no consumo acontece dentro de casa',
    fonte: 'PNUMA/ONU — Food Waste Index 2024',
    ano: '2024',
  },
];

// Cards principais da página de Dados
export const dadosCards: DadoCard[] = [
  {
    valor: '1/3',
    titulo: 'De tudo o que se produz',
    descricao:
      'Cerca de um terço de todos os alimentos produzidos no mundo é perdido ou desperdiçado em alguma etapa, do campo ao prato.',
    fonte: 'FAO — Organização das Nações Unidas para Alimentação e Agricultura',
  },
  {
    valor: '1,05 bi',
    titulo: 'Toneladas em 2022',
    descricao:
      'O mundo desperdiçou aproximadamente 1,05 bilhão de toneladas de alimentos em um único ano — quase o peso de 10 mil navios porta-contêineres.',
    fonte: 'Relatório Food Waste Index 2024 — PNUMA/ONU',
  },
  {
    valor: '60%',
    titulo: 'Desperdício em casa',
    descricao:
      'A maior parte do desperdício no consumo acontece nas residências, ou seja, a mudança começa na nossa cozinha.',
    fonte: 'Relatório Food Waste Index 2024 — PNUMA/ONU',
  },
  {
    valor: '8–10%',
    titulo: 'Das emissões globais',
    descricao:
      'O desperdício de alimentos é responsável por cerca de 8% a 10% das emissões globais de gases de efeito estufa — mais que todo o setor de transporte rodoviário.',
    fonte: 'PNUMA — Programa das Nações Unidas para o Meio Ambiente',
  },
];

// Dados para o gráfico "Onde se desperdiça mais" (consumo)
export const dadosOndeDesperdica = [
  { nome: 'Residências', valor: 60, cor: '#E91E63' },
  { nome: 'Serviços de alimentação', valor: 28, cor: '#2E7D32' },
  { nome: 'Varejo', valor: 12, cor: '#A5D6A7' },
];

// Dados para o gráfico de perdas "Do campo ao prato" (aproximado)
export const dadosCadeia = [
  { etapa: 'Produção', percentual: 14 },
  { etapa: 'Manuseio e armazenamento', percentual: 15 },
  { etapa: 'Processamento', percentual: 6 },
  { etapa: 'Distribuição', percentual: 9 },
  { etapa: 'Consumo (em casa)', percentual: 56 },
];

// Tradução dos dados para o dia a dia
export const dadosTraducao: { titulo: string; texto: string; emoji: string }[] = [
  {
    emoji: '🛒',
    titulo: 'No supermercado',
    texto:
      'Se a cada 3 sacolas de compras uma fosse direto para o lixo, você ficaria indignado. É isso que acontece em escala global com o que compramos e não aproveitamos.',
  },
  {
    emoji: '💰',
    titulo: 'No bolso',
    texto:
      'Uma família brasileira pode jogar fora centenas de reais por mês em alimentos que não foram consumidos a tempo.',
  },
  {
    emoji: '🌍',
    titulo: 'No planeta',
    texto:
      'Desperdiçar comida significa também desperdiçar a água, a energia e o trabalho usados para produzir cada alimento que vai para o lixo.',
  },
  {
    emoji: '🤝',
    titulo: 'Na comunidade',
    texto:
      'Enquanto alimentos são descartados, pessoas próximas podem estar com dificuldade de acesso à comida. Reduzir o desperdício é também um ato de solidariedade.',
  },
];

// Fontes de dados listadas no rodapé e na página de dados
export const fontesDados: string[] = [
  'FAO — Food and Agriculture Organization of the United Nations',
  'PNUMA — Programa das Nações Unidas para o Meio Ambiente',
  'Relatório Food Waste Index 2024 (PNUMA/ONU)',
  'Embrapa — Empresa Brasileira de Pesquisa Agropecuária',
];
