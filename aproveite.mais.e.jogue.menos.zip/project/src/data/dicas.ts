// =============================================================
// dicas.ts — Dicas rápidas e conteúdo de "Como ajudar"
// =============================================================

export interface Dica {
  emoji: string;
  titulo: string;
  descricao: string;
}

export const dicasRapidas: Dica[] = [
  {
    emoji: '📝',
    titulo: 'Planeje as refeições',
    descricao: 'Anote o que vai cozinhar na semana antes de ir às compras.',
  },
  {
    emoji: '🛒',
    titulo: 'Faça uma lista',
    descricao: 'Compre só o que precisa — e não entre na loja com fome!',
  },
  {
    emoji: '❄️',
    titulo: 'Congele sobras',
    descricao: 'Porções extras podem ir ao freezer e virar uma refeição rápida depois.',
  },
  {
    emoji: '🥕',
    titulo: 'Aproveite cascas e talos',
    descricao: 'Cascas de banana, talos de couve e folhas de cenoura têm sabor e nutrientes.',
  },
  {
    emoji: '📦',
    titulo: 'Armazene corretamente',
    descricao: 'Cada alimento tem um lugar ideal: verduras na gaveta, frutas separadas.',
  },
  {
    emoji: '🍳',
    titulo: 'Cozinhe a porção certa',
    descricao: 'Use medidas para não fazer mais do que a família vai comer.',
  },
  {
    emoji: '♻️',
    titulo: 'Composte o que sobra',
    descricao: 'Restos que não dão para comer viram adubo para plantas.',
  },
  {
    emoji: '📅',
    titulo: 'Confira a validade',
    descricao: 'Organize os produtos por data e consuma primeiro os mais próximos do vencimento.',
  },
];

export interface ContextoAjuda {
  icone: string;
  titulo: string;
  itens: { titulo: string; descricao: string }[];
}

export const contextosAjuda: ContextoAjuda[] = [
  {
    icone: '🏠',
    titulo: 'Em casa',
    itens: [
      {
        titulo: 'Planeje suas compras',
        descricao:
          'Antes de ir ao mercado, veja o que você já tem em casa e planeje as refeições da semana. Faça uma lista e siga ela.',
      },
      {
        titulo: 'Armazene corretamente',
        descricao:
          'Frutas, verduras e grãos têm formas ideais de conservação. Mantenha a geladeira organizada para ver tudo o que há dentro.',
      },
      {
        titulo: 'Validade x Consumir antes',
        descricao:
          '"Válido até" indica segurança. "Consumir de preferência antes de" é sobre qualidade. Muitos alimentos estão bons depois dessa data.',
      },
      {
        titulo: 'Congele as sobras',
        descricao:
          'Sobou arroz, feijão ou molho? Congele em porções individuais para uma refeição rápida outro dia.',
      },
      {
        titulo: 'Aproveite cascas, talos e folhas',
        descricao:
          'Talos de couve viram refogado, cascas de banana viram bolo, folhas de cenoura viram pesto. Tudo aproveitado, nada jogado fora.',
      },
    ],
  },
  {
    icone: '🏪',
    titulo: 'No comércio e restaurantes',
    itens: [
      {
        titulo: 'Doe excedentes',
        descricao:
          'Alimentos em boa condição que não serão vendidos podem ser doados para bancos de alimentos, igrejas ou cozinhas comunitárias.',
      },
      {
        titulo: 'Venda produtos "feios"',
        descricao:
          'Frutas e legumes com aparência diferente têm o mesmo sabor e valor. Crie uma seção com desconto para eles.',
      },
      {
        titulo: 'Promoções de接近 da validade',
        descricao:
          'Itens próximos do vencimento podem ganhar etiquetas de desconto para incentivar a compra e o consumo rápido.',
      },
    ],
  },
  {
    icone: '🤝',
    titulo: 'Na comunidade',
    itens: [
      {
        titulo: 'Hortas comunitárias',
        descricao:
          'Reúna vizinhos para cultivar alimentos em terrenos baldios ou praças. Todo mundo colhe, todo mundo aprende.',
      },
      {
        titulo: 'Compostagem coletiva',
        descricao:
          'Junte restos orgânicos de várias casas para fazer composto e usar nas hortas do bairro.',
      },
      {
        titulo: 'Cozinhas solidárias',
        descricao:
          'Cozinhe em conjunto com excedentes doados e distribua refeições para quem precisa.',
      },
      {
        titulo: 'Bancos de alimentos',
        descricao:
          'Apoie ou ajude a organizar pontos de coleta e distribuição de alimentos no seu bairro.',
      },
      {
        titulo: 'Feiras de troca',
        descricao:
          'Organize encontros onde vizinhos trocam alimentos, receitas e mudas de plantas.',
      },
    ],
  },
];

export const passoAPassoMobilizar: { titulo: string; descricao: string }[] = [
  {
    titulo: 'Converse com vizinhos',
    descricao:
      'Comece falando sobre o tema com pessoas próximas. Ouça as experiências delas e compartilhe o que você sabe.',
  },
  {
    titulo: 'Monte um grupo de WhatsApp',
    descricao:
      'Crie um grupo para o bairro ou condomínio. O importante é ter um espaço fácil para trocar informações.',
  },
  {
    titulo: 'Mapeie excedente e necessidade',
    descricao:
      'Identifique quem costuma ter comida sobrando e quem poderia receber. O grupo ajuda a fazer essa ponte.',
  },
  {
    titulo: 'Faça uma ação-piloto',
    descricao:
      'Organize um mutirão de aproveitamento ou uma feira de trocas. Comece pequeno para aprender com a prática.',
  },
  {
    titulo: 'Compartilhe os resultados',
    descricao:
      'Mostre o que funcionou, celebre cada conquista e convide mais pessoas. Resultados visíveis inspiram mais participação.',
  },
];

// Receitas curtas de aproveitamento integral
export const receitasCurta: { nome: string; ingredientes: string; emoji: string }[] = [
  {
    emoji: '🥬',
    nome: 'Refogado de talos',
    ingredientes: 'Talos de couve, beterraba ou espinafre refogados com alho e azeite.',
  },
  {
    emoji: '🍌',
    nome: 'Bolo de casca de banana',
    ingredientes: 'Cascas de banana madura batidas no liquidificador com massa de bolo simples.',
  },
  {
    emoji: '🥕',
    nome: 'Pesto de folhas de cenoura',
    ingredientes: 'Folhas de cenoura, alho, azeite, nozes e queijo batidos até virar pasta.',
  },
];
