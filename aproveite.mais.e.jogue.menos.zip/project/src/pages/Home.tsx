import { Link } from 'react-router-dom';
import { ArrowRight, Heart, ShoppingBag, Leaf, Coins, Sparkles } from 'lucide-react';
import AnimatedCounter from '@/components/AnimatedCounter';
import AtalhosCards from '@/components/AtalhosCards';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { dadosImpacto } from '@/data/dados';

const impactos = [
  {
    icone: Heart,
    cor: 'rosa',
    titulo: 'Impacto social',
    texto:
      'Reduzir o desperdício significa mais comida disponível para quem precisa. É um gesto de cuidado com as pessoas ao nosso redor.',
  },
  {
    icone: Leaf,
    cor: 'verde',
    titulo: 'Impacto ambiental',
    texto:
      'Cada alimento desperdiçado levou água, energia e terra para ser produzido. Aproveitar melhor é respeitar o planeta.',
  },
  {
    icone: Coins,
    cor: 'rosa',
    titulo: 'Impacto econômico',
    texto:
      'Comer o que se compra economiza dinheiro. Uma família pode poupar centenas de reais por mês ao evitar desperdícios.',
  },
];

export default function Home() {
  const { ref: impactRef, visible: impactVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: ctaRef, visible: ctaVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <>
      {/* Hero */}
      <section className="relative gradient-hero pt-20 md:pt-32 pb-16 md:pb-28 overflow-hidden">
        {/* Decoração SVG — frutas e legumes flutuantes */}
        <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
          <span className="absolute top-20 left-[6%] text-3xl md:text-5xl opacity-40 animate-fade-in">🍅</span>
          <span className="absolute top-32 right-[8%] text-4xl md:text-6xl opacity-30 hidden sm:block">🥬</span>
          <span className="absolute bottom-12 left-[12%] text-2xl md:text-4xl opacity-30">🥕</span>
          <span className="absolute bottom-24 right-[14%] text-3xl md:text-5xl opacity-25 hidden sm:block">🍎</span>
          <span className="absolute top-52 left-[40%] text-2xl md:text-3xl opacity-20 hidden md:block">🌽</span>
          <span className="absolute bottom-16 right-[42%] text-2xl md:text-4xl opacity-20 hidden md:block">🍌</span>
        </div>

        <div className="relative max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-flex items-center gap-2 bg-white/70 backdrop-blur-sm rounded-full px-4 py-2 text-xs md:text-sm font-medium text-verde-principal mb-5 md:mb-6 animate-fade-in">
            <Sparkles className="w-4 h-4" /> Aproveite mais, jogue menos
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] leading-tight md:text-5xl lg:text-6xl text-texto mb-4 md:mb-5 animate-fade-up">
            Metade do prato que sobra pode virar <span className="text-gradient">esperança</span>
          </h1>
          <p className="text-texto-sec text-base md:text-xl leading-relaxed max-w-2xl mx-auto mb-6 md:mb-8 animate-fade-up" style={{ animationDelay: '100ms' }}>
            Pequenas mudanças na sua cozinha podem reduzir o desperdício, economizar dinheiro e
            ajudar quem precisa. Comece hoje, no seu ritmo.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center animate-fade-up" style={{ animationDelay: '200ms' }}>
            <Link
              to="/desafios"
              className="inline-flex items-center justify-center gap-2 bg-rosa-principal text-white font-semibold px-6 md:px-7 py-3.5 rounded-full hover:bg-rosa-principal/90 transition-all duration-200 shadow-md hover:shadow-lg hover:-translate-y-0.5 text-base min-h-[44px]"
            >
              Comece o desafio <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/entenda-e-calcule"
              className="inline-flex items-center justify-center gap-2 border-2 border-verde-principal text-verde-principal font-semibold px-6 md:px-7 py-3.5 rounded-full hover:bg-verde-principal hover:text-white transition-all duration-200 text-base min-h-[44px]"
            >
              Entenda o problema
            </Link>
          </div>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Números de impacto */}
      <section className="bg-bg py-12 md:py-20">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 md:gap-6">
            {dadosImpacto.map((dado, i) => (
              <div
                key={i}
                className="text-center bg-white rounded-3xl p-6 md:p-8 shadow-card hover:shadow-card-hover transition-shadow duration-200"
              >
                <p className="font-titulo font-bold text-3xl md:text-5xl text-verde-principal mb-2">
                  <AnimatedCounter target={parseInt(dado.numero)} suffix={dado.numero === '1050' ? ' mi' : '%'} />
                </p>
                <p className="text-texto-sec leading-relaxed text-sm md:text-base">{dado.descricao}</p>
                <p className="text-xs text-texto-sec/60 mt-3">Fonte: {dado.fonte}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Atalhos */}
      <section className="bg-bg py-10 md:py-16">
        <div className="max-w-7xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Por onde começar"
            titulo="Escolha o seu caminho"
            descricao="Cada passo conta. Veja o que faz mais sentido para você agora."
          />
          <div className="mt-10">
            <AtalhosCards />
          </div>
        </div>
      </section>

      {/* Por que isso importa */}
      <section className="bg-verde-bg py-14 md:py-24 relative">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Por que isso importa?"
            titulo="Três motivos para se importar"
            descricao="O desperdício de alimentos afeta todo mundo — e a solução também começa com cada um."
          />
          <div
            ref={impactRef}
            className={`grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-6 mt-10 md:mt-12 ${impactVisible ? 'visible' : ''} reveal`}
          >
            {impactos.map((item, i) => (
              <div
                key={i}
                style={{ transitionDelay: `${i * 100}ms` }}
                className="bg-white rounded-3xl p-6 md:p-7 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
              >
                <span
                  className={`inline-flex items-center justify-center w-14 h-14 rounded-2xl mb-5 ${
                    item.cor === 'verde'
                      ? 'bg-verde-bg text-verde-principal'
                      : 'bg-rosa-bg text-rosa-principal'
                  }`}
                >
                  <item.icone className="w-7 h-7" />
                </span>
                <h3 className="font-titulo font-semibold text-xl text-texto mb-2">{item.titulo}</h3>
                <p className="text-texto-sec leading-relaxed">{item.texto}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA final */}
      <section className="bg-bg py-14 md:py-24">
        <div
          ref={ctaRef}
          className={`max-w-4xl mx-auto px-5 md:px-6 ${ctaVisible ? 'visible' : ''} reveal`}
        >
          <div className="relative overflow-hidden rounded-3xl md:rounded-4xl bg-gradient-to-br from-verde-principal to-rosa-principal p-6 md:p-14 text-center text-white shadow-lg">
            <div className="absolute inset-0 opacity-10" aria-hidden="true">
              <span className="absolute top-8 left-8 text-5xl">🥗</span>
              <span className="absolute bottom-8 right-8 text-5xl">🍎</span>
              <span className="absolute top-1/2 right-1/4 text-4xl">🥕</span>
            </div>
            <div className="relative">
              <h2 className="font-titulo font-bold text-xl md:text-4xl mb-3 md:mb-4 leading-tight">
                Pronto para fazer a diferença?
              </h2>
              <p className="text-white/90 text-base md:text-lg mb-6 md:mb-7 max-w-xl mx-auto leading-relaxed">
                Junte-se a pessoas que já estão reduzindo o desperdício. Sua participação vale muito.
              </p>
              <Link
                to="/participe"
                className="inline-flex items-center justify-center gap-2 bg-white text-rosa-principal font-bold px-8 py-4 rounded-full hover:bg-white/95 transition-all duration-200 shadow-lg hover:shadow-xl hover:-translate-y-0.5 text-base"
              >
                Quero participar <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
