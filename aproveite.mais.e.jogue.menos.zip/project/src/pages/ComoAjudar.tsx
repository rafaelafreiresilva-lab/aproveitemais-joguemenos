import { useState } from 'react';
import { Download, Share2, CheckCircle, ArrowRight } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { contextosAjuda, passoAPassoMobilizar, dicasRapidas, receitasCurta } from '@/data/dicas';

export default function ComoAjudar() {
  const [abaAtiva, setAbaAtiva] = useState(0);
  const { ref: passosRef, visible: passosVisible } = useScrollReveal<HTMLDivElement>();
  const { ref: dicasRef, visible: dicasVisible } = useScrollReveal<HTMLDivElement>();

  const compartilharWhatsApp = () => {
    const url = encodeURIComponent(window.location.href);
    const texto = encodeURIComponent('Olha esse site sobre reduzir o desperdício de alimentos: ');
    window.open(`https://wa.me/?text=${texto}${url}`, '_blank');
  };

  return (
    <>
      {/* Header da página */}
      <section className="gradient-hero pt-20 md:pt-32 pb-14 md:pb-20">
        <div className="max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-block text-rosa-principal font-semibold text-xs md:text-sm uppercase tracking-wide mb-2">
            Como ajudar
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] md:text-5xl text-texto leading-tight mb-3 md:mb-4">
            Cada gesto conta — do mercado à comunidade
          </h1>
          <p className="text-texto-sec text-base md:text-lg leading-relaxed">
            Pequenas mudanças de hábito, feitas por muitas pessoas, geram um impacto enorme.
            Veja o que você pode fazer em cada contexto.
          </p>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Abas de contexto */}
      <section className="bg-bg py-12 md:py-20">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          {/* Tabs */}
          <div className="flex flex-col sm:flex-row gap-3 mb-8 md:mb-10">
            {contextosAjuda.map((ctx, i) => (
              <button
                key={i}
                onClick={() => setAbaAtiva(i)}
                className={`flex-1 flex items-center justify-center gap-2 px-4 md:px-5 py-3.5 rounded-2xl font-semibold text-sm md:text-base transition-all duration-200 min-h-[48px] ${
                  abaAtiva === i
                    ? 'bg-verde-principal text-white shadow-md'
                    : 'bg-white text-texto-sec border border-verde-bg hover:border-verde-claro'
                }`}
                aria-pressed={abaAtiva === i}
              >
                <span className="text-xl">{ctx.icone}</span>
                {ctx.titulo}
              </button>
            ))}
          </div>

          {/* Conteúdo da aba ativa */}
          <div className="grid gap-4 md:gap-5 md:grid-cols-2 animate-fade-in" key={abaAtiva}>
            {contextosAjuda[abaAtiva].itens.map((item, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-5 md:p-6 shadow-card hover:shadow-card-hover hover:-translate-y-0.5 transition-all duration-200"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-verde-principal shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-titulo font-semibold text-lg text-texto mb-1">{item.titulo}</h3>
                    <p className="text-texto-sec text-sm leading-relaxed">{item.descricao}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Receitas curtas (apenas na aba "Em casa") */}
          {abaAtiva === 0 && (
            <div className="mt-10 animate-fade-in">
              <h3 className="font-titulo font-semibold text-xl text-texto mb-5 text-center">
                Receitas de aproveitamento integral 🍳
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5">
                {receitasCurta.map((rec, i) => (
                  <div key={i} className="bg-rosa-bg rounded-2xl p-5 text-center">
                    <span className="text-4xl block mb-2">{rec.emoji}</span>
                    <h4 className="font-titulo font-semibold text-texto mb-1">{rec.nome}</h4>
                    <p className="text-texto-sec text-sm">{rec.ingredientes}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Botões */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8 md:mt-10">
            <button
              onClick={compartilharWhatsApp}
              className="inline-flex items-center justify-center gap-2 bg-verde-principal text-white font-semibold px-6 py-3.5 rounded-full hover:bg-verde-principal/90 transition-all duration-200 shadow-sm hover:shadow-md min-h-[48px]"
            >
              <Share2 className="w-5 h-5" /> Compartilhar no WhatsApp
            </button>
            <button
              className="inline-flex items-center justify-center gap-2 border-2 border-verde-principal text-verde-principal font-semibold px-6 py-3.5 rounded-full hover:bg-verde-principal hover:text-white transition-all duration-200 min-h-[48px]"
            >
              <Download className="w-5 h-5" /> Baixar checklist
            </button>
          </div>
        </div>
      </section>

      {/* Passo a passo mobilizar */}
      <section className="bg-rosa-bg py-14 md:py-24">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Mobilização"
            titulo="Como mobilizar sua comunidade"
            descricao="Cinco passos para transformar o bairro em uma rede de aproveitamento."
          />
          <div
            ref={passosRef}
            className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-4 mt-10 md:mt-12 ${passosVisible ? 'visible' : ''} reveal`}
          >
            {passoAPassoMobilizar.map((passo, i) => (
              <div
                key={i}
                style={{ transitionDelay: `${i * 100}ms` }}
                className="bg-white rounded-2xl p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 relative"
              >
                <span className="absolute -top-4 -left-4 flex items-center justify-center w-10 h-10 bg-rosa-principal text-white font-titulo font-bold rounded-xl shadow-md">
                  {i + 1}
                </span>
                <h3 className="font-titulo font-semibold text-base text-texto mt-3 mb-2">
                  {passo.titulo}
                </h3>
                <p className="text-texto-sec text-sm leading-relaxed">{passo.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Dicas rápidas */}
      <section className="bg-bg py-14 md:py-24">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Dicas rápidas"
            titulo="8 ideias para começar hoje"
            descricao="Escolha uma, coloque em prática e veja a diferença."
          />
          <div
            ref={dicasRef}
            className={`grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mt-10 md:mt-12 ${dicasVisible ? 'visible' : ''} reveal`}
          >
            {dicasRapidas.map((dica, i) => (
              <div
                key={i}
                style={{ transitionDelay: `${i * 60}ms` }}
                className="bg-white rounded-2xl p-4 md:p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 text-center"
              >
                <span className="text-3xl block mb-2">{dica.emoji}</span>
                <h3 className="font-titulo font-semibold text-sm text-texto mb-1">{dica.titulo}</h3>
                <p className="text-texto-sec text-xs leading-relaxed">{dica.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
