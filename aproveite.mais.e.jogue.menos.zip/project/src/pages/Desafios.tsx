import { useEffect, useState, useCallback } from 'react';
import { CheckCircle2, Circle, Share2, RotateCcw, Trophy } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';
import { semanas, selos } from '@/data/desafios';

const STORAGE_KEY = 'desafios-progresso';

type Progresso = Record<string, boolean>;

function loadProgresso(): Progresso {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function saveProgresso(p: Progresso) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
}

// Componente de confete simples
function Confete() {
  const cores = ['#2E7D32', '#E91E63', '#A5D6A7', '#F8BBD0', '#FFD54F'];
  const pieces = Array.from({ length: 40 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 0.5,
    duration: 2 + Math.random() * 2,
    cor: cores[i % cores.length],
    size: 6 + Math.random() * 8,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-[60] overflow-hidden" aria-hidden="true">
      {pieces.map((p) => (
        <span
          key={p.id}
          className="absolute top-0 rounded"
          style={{
            left: `${p.left}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            backgroundColor: p.cor,
            animation: `confettiFall ${p.duration}s linear ${p.delay}s forwards`,
          }}
        />
      ))}
    </div>
  );
}

export default function Desafios() {
  const [progresso, setProgresso] = useState<Progresso>({});
  const [confetti, setConfetti] = useState<number | null>(null);

  useEffect(() => {
    setProgresso(loadProgresso());
  }, []);

  const toggleTarefa = useCallback((tarefaId: string, semanaId: number) => {
    setProgresso((prev) => {
      const novo = { ...prev, [tarefaId]: !prev[tarefaId] };
      saveProgresso(novo);

      // Verifica se completou a semana
      const semana = semanas.find((s) => s.id === semanaId)!;
      const todasCompletas = semana.tarefas.every((t) => novo[t.id]);
      const estavaCompleta = semana.tarefas.every((t) => prev[t.id]);

      if (todasCompletas && !estavaCompleta) {
        setConfetti(semanaId);
        setTimeout(() => setConfetti(null), 4000);
      }

      return novo;
    });
  }, []);

  const handleReset = () => {
    setProgresso({});
    saveProgresso({});
  };

  const handleShare = () => {
    const totalFeitas = Object.values(progresso).filter(Boolean).length;
    const totalTarefas = semanas.reduce((acc, s) => acc + s.tarefas.length, 0);
    const texto = `Estou no desafio "Aproveite Mais"! Já completei ${totalFeitas} de ${totalTarefas} tarefas. Junte-se a mim!`;
    const url = encodeURIComponent(window.location.href);
    window.open(`https://wa.me/?text=${encodeURIComponent(texto)} ${url}`, '_blank');
  };

  const totalTarefas = semanas.reduce((acc, s) => acc + s.tarefas.length, 0);
  const totalFeitas = Object.values(progresso).filter(Boolean).length;
  const progressoGeral = Math.round((totalFeitas / totalTarefas) * 100);

  const semanasCompletas = semanas.filter((s) =>
    s.tarefas.every((t) => progresso[t.id])
  ).length;

  return (
    <>
      {/* Header */}
      <section className="gradient-hero pt-20 md:pt-32 pb-14 md:pb-20">
        <div className="max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-block text-rosa-principal font-semibold text-xs md:text-sm uppercase tracking-wide mb-2">
            Desafios semanais
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] md:text-5xl text-texto leading-tight mb-3 md:mb-4">
            4 semanas para aproveitar mais
          </h1>
          <p className="text-texto-sec text-base md:text-lg leading-relaxed">
            Cada semana tem 5 tarefas pequenas. Marque conforme avança, ganhe selos e veja sua
            evolução. Seu progresso fica salvo no seu navegador.
          </p>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Progresso geral */}
      <section className="bg-bg py-10 md:py-16">
        <div className="max-w-4xl mx-auto px-5 md:px-6">
          <div className="bg-white rounded-3xl p-5 md:p-8 shadow-card">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-5">
              <div className="text-center md:text-left">
                <h2 className="font-titulo font-semibold text-lg md:text-xl text-texto">Seu progresso geral</h2>
                <p className="text-texto-sec text-sm">
                  {totalFeitas} de {totalTarefas} tarefas completas
                </p>
              </div>
              <div className="text-center">
                <span className="font-titulo font-bold text-4xl text-verde-principal">
                  {progressoGeral}%
                </span>
                <p className="text-texto-sec text-xs">{semanasCompletas}/4 semanas completas</p>
              </div>
            </div>
            {/* Barra de progresso */}
            <div className="w-full h-4 bg-verde-bg rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-verde-principal to-rosa-principal rounded-full transition-all duration-500"
                style={{ width: `${progressoGeral}%` }}
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-3 mt-6">
              <button
                onClick={handleShare}
                className="inline-flex items-center justify-center gap-2 bg-verde-principal text-white font-semibold px-5 py-3 rounded-full hover:bg-verde-principal/90 transition-all duration-200 text-sm"
              >
                <Share2 className="w-4 h-4" /> Compartilhar conquista
              </button>
              <button
                onClick={handleReset}
                className="inline-flex items-center justify-center gap-2 border-2 border-texto-sec/30 text-texto-sec font-semibold px-5 py-3 rounded-full hover:border-rosa-principal hover:text-rosa-principal transition-all duration-200 text-sm"
              >
                <RotateCcw className="w-4 h-4" /> Reiniciar desafios
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Selos de conquista */}
      <section className="bg-bg pb-10 md:pb-16">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          <h2 className="font-titulo font-semibold text-lg md:text-xl text-texto mb-4 md:mb-5 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-rosa-principal" /> Selos de conquista
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
            {selos.map((selo) => {
              const desbloqueado = semanas
                .find((s) => s.id === selo.semanaId)!
                .tarefas.every((t) => progresso[t.id]);
              return (
                <div
                  key={selo.semanaId}
                  className={`rounded-2xl p-4 md:p-5 text-center transition-all duration-300 ${
                    desbloqueado
                      ? 'bg-gradient-to-br from-verde-bg to-rosa-bg shadow-card scale-100'
                      : 'bg-gray-100 opacity-50 grayscale'
                  }`}
                >
                  <span className={`text-4xl block mb-2 ${desbloqueado ? '' : 'opacity-40'}`}>
                    {selo.emoji}
                  </span>
                  <h3 className="font-titulo font-semibold text-sm text-texto">{selo.nome}</h3>
                  <p className="text-texto-sec text-xs mt-1 leading-relaxed">{selo.descricao}</p>
                  {desbloqueado && (
                    <span className="inline-block mt-2 text-xs font-bold text-verde-principal bg-white rounded-full px-3 py-1">
                      Desbloqueado!
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Semanas */}
      <section className="bg-verde-bg py-14 md:py-20">
        <div className="max-w-4xl mx-auto px-5 md:px-6 space-y-5 md:space-y-6">
          {semanas.map((semana) => {
            const feitas = semana.tarefas.filter((t) => progresso[t.id]).length;
            const pct = Math.round((feitas / semana.tarefas.length) * 100);
            const completa = feitas === semana.tarefas.length;

            return (
              <div
                key={semana.id}
                className="bg-white rounded-3xl p-5 md:p-8 shadow-card transition-all duration-200"
              >
                <div className="flex items-start gap-3 md:gap-4 mb-4 md:mb-5">
                  <span className="text-2xl md:text-4xl shrink-0">{semana.emoji}</span>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-bold text-rosa-principal bg-rosa-bg rounded-full px-3 py-1">
                        Semana {semana.id}
                      </span>
                      {completa && (
                        <span className="text-xs font-bold text-verde-principal bg-verde-bg rounded-full px-3 py-1">
                          Completa!
                        </span>
                      )}
                    </div>
                    <h3 className="font-titulo font-bold text-lg md:text-xl text-texto">{semana.titulo}</h3>
                    <p className="text-texto-sec text-xs md:text-sm mt-1 leading-relaxed">{semana.descricao}</p>
                  </div>
                </div>

                {/* Barra de progresso da semana */}
                <div className="w-full h-2.5 bg-verde-bg rounded-full overflow-hidden mb-5">
                  <div
                    className="h-full bg-verde-principal rounded-full transition-all duration-300"
                    style={{ width: `${pct}%` }}
                  />
                </div>

                {/* Tarefas */}
                <ul className="space-y-2">
                  {semana.tarefas.map((tarefa) => {
                    const feito = progresso[tarefa.id];
                    return (
                      <li key={tarefa.id}>
                        <button
                          onClick={() => toggleTarefa(tarefa.id, semana.id)}
                          className="flex items-center gap-3 w-full text-left p-3 rounded-xl hover:bg-verde-bg/50 transition-colors duration-150 min-h-[48px]"
                          aria-pressed={feito}
                        >
                          {feito ? (
                            <CheckCircle2 className="w-5 h-5 text-verde-principal shrink-0" />
                          ) : (
                            <Circle className="w-5 h-5 text-verde-claro shrink-0" />
                          )}
                          <span
                            className={`text-sm ${
                              feito ? 'line-through text-texto-sec/60' : 'text-texto'
                            }`}
                          >
                            {tarefa.texto}
                          </span>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>
      </section>

      {/* Confete */}
      {confetti !== null && <Confete />}
    </>
  );
}
