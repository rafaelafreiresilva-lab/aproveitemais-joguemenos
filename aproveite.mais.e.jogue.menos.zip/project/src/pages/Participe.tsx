import { useState } from 'react';
import { CheckCircle2, Send, MessageCircle, UserPlus, Instagram, AlertCircle } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';

interface FormData {
  nome: string;
  email: string;
  cidade: string;
  participacao: string;
  interesses: string[];
  mensagem: string;
  aceite: boolean;
}

interface Errors {
  nome?: string;
  email?: string;
  cidade?: string;
  participacao?: string;
  aceite?: string;
}

const tiposParticipacao = [
  'Sou morador',
  'Tenho comércio ou restaurante',
  'Represento uma ONG ou projeto',
  'Quero voluntariar',
];

const interessesLista = [
  { id: 'dicas', label: 'Receber dicas' },
  { id: 'receitas', label: 'Receber receitas' },
  { id: 'mutiroes', label: 'Participar de mutirões' },
  { id: 'doar', label: 'Doar excedentes' },
];

export default function Participe() {
  const [form, setForm] = useState<FormData>({
    nome: '',
    email: '',
    cidade: '',
    participacao: '',
    interesses: [],
    mensagem: '',
    aceite: false,
  });
  const [errors, setErrors] = useState<Errors>({});
  const [enviado, setEnviado] = useState(false);

  const validate = (): boolean => {
    const e: Errors = {};
    if (!form.nome.trim()) e.nome = 'Por favor, digite seu nome.';
    if (!form.email.trim()) {
      e.email = 'Por favor, digite seu e-mail.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      e.email = 'Digite um e-mail válido (ex: nome@email.com).';
    }
    if (!form.cidade.trim()) e.cidade = 'Por favor, digite sua cidade ou bairro.';
    if (!form.participacao) e.participacao = 'Selecione uma opção.';
    if (!form.aceite) e.aceite = 'Você precisa aceitar a política de privacidade para continuar.';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (validate()) {
      // Salva no localStorage (simulação sem backend)
      try {
        const existing = JSON.parse(localStorage.getItem('participantes') || '[]');
        existing.push({ ...form, data: new Date().toISOString() });
        localStorage.setItem('participantes', JSON.stringify(existing));
      } catch {
        // Ignora erros de storage
      }
      setEnviado(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const toggleInteresse = (id: string) => {
    setForm((prev) => ({
      ...prev,
      interesses: prev.interesses.includes(id)
        ? prev.interesses.filter((i) => i !== id)
        : [...prev.interesses, id],
    }));
  };

  const handleShareWhatsApp = () => {
    const texto = 'Participe do movimento "Aproveite Mais" — aproveite mais, jogue menos!';
    const url = encodeURIComponent(window.location.href);
    window.open(`https://wa.me/?text=${encodeURIComponent(texto)} ${url}`, '_blank');
  };

  if (enviado) {
    return (
      <>
        <section className="gradient-hero pt-20 md:pt-32 pb-16 md:pb-28">
          <div className="max-w-2xl mx-auto text-center px-5 md:px-6">
            <div className="inline-flex items-center justify-center w-16 h-16 md:w-20 md:h-20 bg-white rounded-full shadow-lg mb-5 md:mb-6 animate-fade-in">
              <CheckCircle2 className="w-8 h-8 md:w-10 md:h-10 text-verde-principal" />
            </div>
            <h1 className="font-titulo font-bold text-2xl md:text-4xl text-texto mb-3 md:mb-4 animate-fade-up">
              Obrigado por participar!
            </h1>
            <p className="text-texto-sec text-base md:text-lg leading-relaxed mb-6 md:mb-8 animate-fade-up" style={{ animationDelay: '100ms' }}>
              Recebemos sua inscrição. Em breve entraremos em contato com dicas, receitas e
              oportunidades de participação na sua região. Juntos, vamos aproveitar mais e jogar
              menos.
            </p>
            <button
              onClick={() => {
                setEnviado(false);
                setForm({
                  nome: '', email: '', cidade: '', participacao: '',
                  interesses: [], mensagem: '', aceite: false,
                });
              }}
              className="inline-flex items-center gap-2 bg-verde-principal text-white font-semibold px-6 py-3.5 rounded-full hover:bg-verde-principal/90 transition-all duration-200 shadow-md"
            >
              Inscrever outra pessoa
            </button>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      {/* Header */}
      <section className="gradient-hero pt-20 md:pt-32 pb-14 md:pb-20">
        <div className="max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-block text-rosa-principal font-semibold text-xs md:text-sm uppercase tracking-wide mb-2">
            Participe
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] md:text-5xl text-texto leading-tight mb-3 md:mb-4">
            Junte-se ao movimento
          </h1>
          <p className="text-texto-sec text-base md:text-lg leading-relaxed">
            Preencha o formulário e receba dicas, receitas e oportunidades de participar na sua
            comunidade.
          </p>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Formulário */}
      <section className="bg-bg py-12 md:py-20">
        <div className="max-w-3xl mx-auto px-5 md:px-6">
          <form
            onSubmit={handleSubmit}
            noValidate
            className="bg-white rounded-3xl p-5 md:p-8 shadow-card space-y-5 md:space-y-6"
          >
            {/* Nome */}
            <div>
              <label htmlFor="nome" className="block font-titulo font-semibold text-texto mb-2">
                Nome *
              </label>
              <input
                id="nome"
                type="text"
                value={form.nome}
                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                className={`w-full px-4 py-3.5 rounded-xl border-2 transition-colors duration-200 text-texto text-base outline-none min-h-[48px] ${
                  errors.nome
                    ? 'border-rosa-principal bg-rosa-bg/30'
                    : 'border-verde-bg focus:border-verde-principal'
                }`}
                placeholder="Seu nome completo"
                aria-invalid={!!errors.nome}
              />
              {errors.nome && (
                <p className="mt-1.5 text-sm text-rosa-principal flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> {errors.nome}
                </p>
              )}
            </div>

            {/* E-mail */}
            <div>
              <label htmlFor="email" className="block font-titulo font-semibold text-texto mb-2">
                E-mail *
              </label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className={`w-full px-4 py-3.5 rounded-xl border-2 transition-colors duration-200 text-texto text-base outline-none min-h-[48px] ${
                  errors.email
                    ? 'border-rosa-principal bg-rosa-bg/30'
                    : 'border-verde-bg focus:border-verde-principal'
                }`}
                placeholder="nome@email.com"
                aria-invalid={!!errors.email}
              />
              {errors.email && (
                <p className="mt-1.5 text-sm text-rosa-principal flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> {errors.email}
                </p>
              )}
            </div>

            {/* Cidade */}
            <div>
              <label htmlFor="cidade" className="block font-titulo font-semibold text-texto mb-2">
                Cidade / Bairro *
              </label>
              <input
                id="cidade"
                type="text"
                value={form.cidade}
                onChange={(e) => setForm({ ...form, cidade: e.target.value })}
                className={`w-full px-4 py-3.5 rounded-xl border-2 transition-colors duration-200 text-texto text-base outline-none min-h-[48px] ${
                  errors.cidade
                    ? 'border-rosa-principal bg-rosa-bg/30'
                    : 'border-verde-bg focus:border-verde-principal'
                }`}
                placeholder="Ex: São Paulo, Pinheiros"
                aria-invalid={!!errors.cidade}
              />
              {errors.cidade && (
                <p className="mt-1.5 text-sm text-rosa-principal flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> {errors.cidade}
                </p>
              )}
            </div>

            {/* Tipo de participação */}
            <div>
              <label className="block font-titulo font-semibold text-texto mb-2">
                Tipo de participação *
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {tiposParticipacao.map((tipo) => (
                  <button
                    key={tipo}
                    type="button"
                    onClick={() => setForm({ ...form, participacao: tipo })}
                    className={`px-4 py-3.5 rounded-xl font-medium text-sm transition-all duration-200 text-left min-h-[48px] ${
                      form.participacao === tipo
                        ? 'bg-verde-principal text-white'
                        : 'bg-verde-bg text-texto-sec hover:bg-verde-claro/40'
                    }`}
                    aria-pressed={form.participacao === tipo}
                  >
                    {tipo}
                  </button>
                ))}
              </div>
              {errors.participacao && (
                <p className="mt-1.5 text-sm text-rosa-principal flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> {errors.participacao}
                </p>
              )}
            </div>

            {/* Interesses */}
            <div>
              <label className="block font-titulo font-semibold text-texto mb-2">
                Interesses (opcional)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {interessesLista.map((interesse) => (
                  <button
                    key={interesse.id}
                    type="button"
                    onClick={() => toggleInteresse(interesse.id)}
                    className={`px-3 py-3.5 rounded-xl font-medium text-sm transition-all duration-200 min-h-[48px] ${
                      form.interesses.includes(interesse.id)
                        ? 'bg-rosa-principal text-white'
                        : 'bg-rosa-bg text-texto-sec hover:bg-rosa-claro/30'
                    }`}
                    aria-pressed={form.interesses.includes(interesse.id)}
                  >
                    {interesse.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mensagem */}
            <div>
              <label htmlFor="mensagem" className="block font-titulo font-semibold text-texto mb-2">
                Mensagem (opcional)
              </label>
              <textarea
                id="mensagem"
                value={form.mensagem}
                onChange={(e) => setForm({ ...form, mensagem: e.target.value })}
                rows={4}
                className="w-full px-4 py-3.5 rounded-xl border-2 border-verde-bg focus:border-verde-principal transition-colors duration-200 text-texto outline-none resize-none"
                placeholder="Conte um pouco sobre o que você gostaria de fazer ou compartilhar."
              />
            </div>

            {/* Aceite LGPD */}
            <div>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={form.aceite}
                  onChange={(e) => setForm({ ...form, aceite: e.target.checked })}
                  className="mt-1 w-5 h-5 accent-verde-principal shrink-0"
                />
                <span className="text-sm text-texto-sec leading-relaxed">
                  Aceito a política de privacidade (LGPD) e autorizo o uso dos meus dados para
                  contato relacionado ao projeto. Seus dados não serão compartilhados com terceiros.
                </span>
              </label>
              {errors.aceite && (
                <p className="mt-1.5 text-sm text-rosa-principal flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" /> {errors.aceite}
                </p>
              )}
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 bg-rosa-principal text-white font-bold px-6 py-4 rounded-full hover:bg-rosa-principal/90 transition-all duration-200 shadow-md hover:shadow-lg text-lg"
            >
              <Send className="w-5 h-5" /> Enviar inscrição
            </button>
          </form>

          {/* Outras formas de participar */}
          <div className="mt-10">
            <SectionHeading
              eyebrow="Outras formas"
              titulo="Mais jeitos de participar"
              centro={false}
            />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 md:gap-4 mt-6">
              <button
                onClick={handleShareWhatsApp}
                className="bg-white rounded-2xl p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 text-center"
              >
                <MessageCircle className="w-7 h-7 text-verde-principal mx-auto mb-2" />
                <h3 className="font-titulo font-semibold text-texto text-sm">Compartilhar no WhatsApp</h3>
                <p className="text-texto-sec text-xs mt-1">Espalhe a ideia para amigos e familiares.</p>
              </button>
              <div className="bg-white rounded-2xl p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 text-center">
                <UserPlus className="w-7 h-7 text-rosa-principal mx-auto mb-2" />
                <h3 className="font-titulo font-semibold text-texto text-sm">Convide um vizinho</h3>
                <p className="text-texto-sec text-xs mt-1">A mudança fica mais forte em grupo.</p>
              </div>
              <div className="bg-white rounded-2xl p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 text-center">
                <Instagram className="w-7 h-7 text-rosa-principal mx-auto mb-2" />
                <h3 className="font-titulo font-semibold text-texto text-sm">Siga nas redes</h3>
                <p className="text-texto-sec text-xs mt-1">Receba novidades e dicas todos os dias.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
