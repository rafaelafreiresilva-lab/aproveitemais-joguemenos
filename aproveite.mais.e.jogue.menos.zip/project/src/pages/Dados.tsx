import { BarChart, Bar, XAxis, YAxis, Cell, ResponsiveContainer, PieChart, Pie, Tooltip, Legend } from 'recharts';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';
import { useScrollReveal } from '@/hooks/useScrollReveal';
import { dadosCards, dadosOndeDesperdica, dadosCadeia, dadosTraducao, fontesDados } from '@/data/dados';

export default function Dados() {
  const { ref: tradRef, visible: tradVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <>
      {/* Header */}
      <section className="gradient-hero pt-20 md:pt-32 pb-14 md:pb-20">
        <div className="max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-block text-rosa-principal font-semibold text-xs md:text-sm uppercase tracking-wide mb-2">
            Dados do desperdício
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] md:text-5xl text-texto leading-tight mb-3 md:mb-4">
            Os números que precisamos enfrentar
          </h1>
          <p className="text-texto-sec text-base md:text-lg leading-relaxed">
            Dados de fontes confiáveis que ajudam a entender a dimensão do desperdício de alimentos
            no mundo e onde ele acontece.
          </p>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Cards principais */}
      <section className="bg-bg py-12 md:py-20">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
            {dadosCards.map((card, i) => (
              <div
                key={i}
                className="bg-white rounded-3xl p-6 md:p-7 shadow-card hover:shadow-card-hover transition-shadow duration-200"
              >
                <p className="font-titulo font-bold text-3xl md:text-5xl text-gradient mb-3">
                  {card.valor}
                </p>
                <h3 className="font-titulo font-semibold text-lg text-texto mb-2">{card.titulo}</h3>
                <p className="text-texto-sec text-sm leading-relaxed mb-3">{card.descricao}</p>
                <p className="text-xs text-texto-sec/60 border-t border-verde-bg pt-3">
                  Fonte: {card.fonte}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gráficos */}
      <section className="bg-verde-bg py-14 md:py-20">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Gráficos"
            titulo="Onde se desperdiça mais"
            descricao="O desperdício não está só no supermercado — a maior parte começa em casa."
          />

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8 mt-8 md:mt-10">
            {/* Gráfico de rosca — Onde se desperdiça */}
            <div className="bg-white rounded-3xl p-5 md:p-8 shadow-card">
              <h3 className="font-titulo font-semibold text-base md:text-lg text-texto mb-4 text-center">
                Desperdício no consumo (%) — por setor
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={dadosOndeDesperdica}
                    dataKey="valor"
                    nameKey="nome"
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    innerRadius={55}
                    paddingAngle={3}
                  >
                    {dadosOndeDesperdica.map((entry, i) => (
                      <Cell key={i} fill={entry.cor} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value) => `${value}%`}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 2px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Legend
                    verticalAlign="bottom"
                    iconType="circle"
                    wrapperStyle={{ fontSize: '14px', paddingTop: '12px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <p className="text-xs text-texto-sec/60 text-center mt-2">
                Fonte: PNUMA/ONU — Food Waste Index 2024
              </p>
            </div>

            {/* Gráfico de barras — Do campo ao prato */}
            <div className="bg-white rounded-3xl p-5 md:p-8 shadow-card">
              <h3 className="font-titulo font-semibold text-base md:text-lg text-texto mb-4 text-center">
                Perdas na cadeia — do campo ao prato (%)
              </h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dadosCadeia} margin={{ top: 10, right: 10, left: -10, bottom: 10 }}>
                  <XAxis
                    dataKey="etapa"
                    tick={{ fontSize: 11, fill: '#5B6B62' }}
                    interval={0}
                    angle={-15}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12, fill: '#5B6B62' }} />
                  <Tooltip
                    formatter={(value) => `${value}%`}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 2px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="percentual" radius={[8, 8, 0, 0]}>
                    {dadosCadeia.map((_, i) => (
                      <Cell key={i} fill={i === 4 ? '#E91E63' : '#2E7D32'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <p className="text-xs text-texto-sec/60 text-center mt-2">
                Fonte: FAO — estimativas aproximadas
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* O que significa para você */}
      <section className="bg-bg py-14 md:py-20">
        <div className="max-w-6xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Na prática"
            titulo="O que esses números significam para você"
            descricao="Os dados globais parecem distantes, mas se traduzem em coisas do seu dia a dia."
          />
          <div
            ref={tradRef}
            className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 mt-8 md:mt-10 ${tradVisible ? 'visible' : ''} reveal`}
          >
            {dadosTraducao.map((item, i) => (
              <div
                key={i}
                style={{ transitionDelay: `${i * 80}ms` }}
                className="bg-white rounded-2xl p-5 md:p-6 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200 text-center"
              >
                <span className="text-4xl block mb-3">{item.emoji}</span>
                <h3 className="font-titulo font-semibold text-texto mb-2">{item.titulo}</h3>
                <p className="text-texto-sec text-sm leading-relaxed">{item.texto}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fontes */}
      <section className="bg-rosa-bg py-10 md:py-16">
        <div className="max-w-3xl mx-auto px-5 md:px-6">
          <h3 className="font-titulo font-semibold text-xl text-texto mb-4 text-center">
            Fontes e referências
          </h3>
          <ul className="space-y-2">
            {fontesDados.map((fonte, i) => (
              <li
                key={i}
                className="bg-white/70 rounded-xl px-5 py-3 text-sm text-texto-sec flex items-start gap-2"
              >
                <span className="text-verde-principal font-bold">•</span> {fonte}
              </li>
            ))}
          </ul>
          <p className="text-xs text-texto-sec/60 text-center mt-4">
            Os números deste site são estimativas de fontes oficiais e podem ser atualizados.
            Verifique sempre as fontes originais para informações precisas.
          </p>
        </div>
      </section>
    </>
  );
}
