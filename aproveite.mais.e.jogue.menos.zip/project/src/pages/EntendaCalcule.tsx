import { Sprout, Truck, Factory, Store, Home, Scale, Camera, Calculator as CalcIcon } from 'lucide-react';
import SectionHeading from '@/components/SectionHeading';
import WaveDivider from '@/components/WaveDivider';
import Calculadora from '@/components/Calculadora';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const metodos = [
  {
    icone: Scale,
    titulo: 'Pesar e anotar',
    descricao:
      'Separe o lixo orgânico por uma semana e pese antes de descartar. Anote os valores diários. No fim, some e veja quanto sai por mês.',
  },
  {
    icone: Camera,
    titulo: 'Fotografar e observar',
    descricao:
      'Tire uma foto do prato antes e depois de cada refeição por uma semana. No fim, veja os padrões: o que mais sobra? Por quê?',
  },
  {
    icone: CalcIcon,
    titulo: 'Calculadora rápida',
    descricao:
      'Responda algumas perguntas simples sobre seus hábitos e receba uma estimativa. É o que você pode fazer logo abaixo!',
  },
];

const linhaTempo = [
  { icone: Sprout, etapa: 'Produção', descricao: 'Colheita, manejo e seleção — frutas "feias" ficam no campo.', cor: 'verde' },
  { icone: Truck, etapa: 'Manuseio e armazenamento', descricao: 'Transporte e guarda inadequados causam perdas por estrago.', cor: 'verde' },
  { icone: Factory, etapa: 'Processamento', descricao: 'Na indústria, parte é descartada no preparo e embalagem.', cor: 'rosa' },
  { icone: Store, etapa: 'Distribuição', descricao: 'Supermercados e feiras perdem produtos por validade e manuseio.', cor: 'rosa' },
  { icone: Home, etapa: 'Consumo em casa', descricao: 'A maior parte do desperdício acontece na nossa cozinha.', cor: 'rosa' },
];

export default function EntendaCalcule() {
  const { ref: timelineRef, visible: timelineVisible } = useScrollReveal<HTMLDivElement>();

  return (
    <>
      {/* Header */}
      <section className="gradient-hero pt-20 md:pt-32 pb-14 md:pb-20">
        <div className="max-w-4xl mx-auto text-center px-5 md:px-6">
          <span className="inline-block text-rosa-principal font-semibold text-xs md:text-sm uppercase tracking-wide mb-2">
            Entenda e calcule
          </span>
          <h1 className="font-titulo font-bold text-[1.75rem] md:text-5xl text-texto leading-tight mb-3 md:mb-4">
            Do campo ao prato: onde a comida se perde
          </h1>
          <p className="text-texto-sec text-base md:text-lg leading-relaxed">
            Entender o problema é o primeiro passo. Depois, calcule o seu desperdício e descubra
            onde pode melhorar.
          </p>
        </div>
      </section>

      <WaveDivider cor="#FFFDFB" direcao="top" />

      {/* Parte A: Entenda o problema */}
      <section className="bg-bg py-12 md:py-20">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Entenda o problema"
            titulo="Perda x Desperdício"
            descricao="São coisas parecidas, mas com diferenças importantes."
            centro={false}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5 mt-6 md:mt-8">
            <div className="bg-verde-bg rounded-2xl p-5 md:p-6">
              <h3 className="font-titulo font-semibold text-base md:text-lg text-verde-principal mb-2">
                🌾 Perda (na produção)
              </h3>
              <p className="text-texto-sec text-sm leading-relaxed">
                Acontece antes do alimento chegar ao consumidor: na colheita, no transporte, no
                armazenamento. Muita comida se perde por condições inadequadas, pragas ou seleção
                visual que descarta produtos perfeitamente comestíveis.
              </p>
            </div>
            <div className="bg-rosa-bg rounded-2xl p-5 md:p-6">
              <h3 className="font-titulo font-semibold text-base md:text-lg text-rosa-principal mb-2">
                🍽️ Desperdício (no consumo)
              </h3>
              <p className="text-texto-sec text-sm leading-relaxed">
                Acontece quando o alimento já está pronto para comer, mas é descartado. Inclui o que
                sobra no prato, o que estraga na geladeira e o que esquecemos no fundo da despensa.
                É onde mais podemos agir.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Linha do tempo */}
      <section className="bg-verde-bg py-14 md:py-20">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Do campo ao prato"
            titulo="Onde o alimento se perde"
            descricao="Cada etapa da jornada tem pontos de perda — e oportunidades de melhoria."
          />
          <div
            ref={timelineRef}
            className={`mt-10 md:mt-12 ${timelineVisible ? 'visible' : ''} reveal`}
          >
            {/* Linha conectora */}
            <div className="hidden md:block absolute left-1/2 -translate-x-1/2 w-1 h-full bg-verde-claro/40 rounded-full mt-12" />
            <div className="space-y-3 md:space-y-0">
              {linhaTempo.map((item, i) => (
                <div
                  key={i}
                  style={{ transitionDelay: `${i * 120}ms` }}
                  className={`flex items-start gap-3 md:items-center md:gap-4 bg-white rounded-2xl p-4 md:p-5 shadow-card hover:shadow-card-hover transition-all duration-200 ${
                    i % 2 === 0 ? 'md:ml-0 md:mr-auto md:w-[48%]' : 'md:mr-0 md:ml-auto md:w-[48%]'
                  } ${i > 0 ? 'md:mt-4' : ''}`}
                >
                  <span
                    className={`flex items-center justify-center w-10 h-10 md:w-12 md:h-12 rounded-2xl shrink-0 ${
                      item.cor === 'verde'
                        ? 'bg-verde-bg text-verde-principal'
                        : 'bg-rosa-bg text-rosa-principal'
                    }`}
                  >
                    <item.icone className="w-6 h-6" />
                  </span>
                  <div>
                    <h3 className="font-titulo font-semibold text-sm md:text-base text-texto">{item.etapa}</h3>
                    <p className="text-texto-sec text-xs md:text-sm leading-relaxed">{item.descricao}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Parte B: Métodos de cálculo */}
      <section className="bg-bg py-14 md:py-20">
        <div className="max-w-5xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Jeitos de calcular"
            titulo="Como medir o seu desperdício"
            descricao="Escolha o método que funciona para você — ou use a calculadora abaixo."
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-5 mt-8 md:mt-10">
            {metodos.map((metodo, i) => (
              <div
                key={i}
                className="bg-white rounded-2xl p-5 md:p-6 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
              >
                <span className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-rosa-bg text-rosa-principal mb-4">
                  <metodo.icone className="w-6 h-6" />
                </span>
                <h3 className="font-titulo font-semibold text-lg text-texto mb-2">
                  {i + 1}. {metodo.titulo}
                </h3>
                <p className="text-texto-sec text-sm leading-relaxed">{metodo.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Calculadora interativa */}
      <section className="bg-verde-bg py-14 md:py-24">
        <div className="max-w-2xl mx-auto px-5 md:px-6">
          <SectionHeading
            eyebrow="Calculadora rápida"
            titulo="Calcule seu desperdício"
            descricao="Responda as perguntas e veja uma estimativa do quanto você pode estar desperdiçando."
          />
          <div className="mt-10">
            <Calculadora />
          </div>
        </div>
      </section>
    </>
  );
}
