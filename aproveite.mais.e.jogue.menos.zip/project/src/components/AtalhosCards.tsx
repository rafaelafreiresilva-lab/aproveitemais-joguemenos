import { Link } from 'react-router-dom';
import { ArrowRight, Sprout, Calculator, Trophy, Users } from 'lucide-react';
import { useScrollReveal } from '@/hooks/useScrollReveal';

const atalhos = [
  {
    to: '/como-ajudar',
    titulo: 'Como ajudar',
    descricao: 'Dicas práticas para casa, comércio e comunidade.',
    icone: Sprout,
    cor: 'verde',
  },
  {
    to: '/entenda-e-calcule',
    titulo: 'Calcule seu desperdício',
    descricao: 'Veja quanto você pode estar desperdiçando por mês.',
    icone: Calculator,
    cor: 'rosa',
  },
  {
    to: '/desafios',
    titulo: 'Desafios semanais',
    descricao: '4 semanas com tarefas simples e selos de conquista.',
    icone: Trophy,
    cor: 'verde',
  },
  {
    to: '/participe',
    titulo: 'Participe',
    descricao: 'Junte-se ao movimento e receba dicas e receitas.',
    icone: Users,
    cor: 'rosa',
  },
];

export default function AtalhosCards() {
  const { ref, visible } = useScrollReveal<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5 ${visible ? 'visible' : ''} reveal`}
    >
      {atalhos.map((atalho, i) => (
        <Link
          key={atalho.to}
          to={atalho.to}
          style={{ transitionDelay: `${i * 80}ms` }}
          className="group bg-white rounded-3xl p-6 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-200"
        >
          <span
            className={`inline-flex items-center justify-center w-12 h-12 rounded-2xl mb-4 ${
              atalho.cor === 'verde' ? 'bg-verde-bg text-verde-principal' : 'bg-rosa-bg text-rosa-principal'
            }`}
          >
            <atalho.icone className="w-6 h-6" />
          </span>
          <h3 className="font-titulo font-semibold text-lg text-texto mb-1">{atalho.titulo}</h3>
          <p className="text-texto-sec text-sm leading-relaxed mb-3">{atalho.descricao}</p>
          <span className="inline-flex items-center gap-1 text-rosa-principal font-medium text-sm group-hover:gap-2 transition-all">
            Saiba mais <ArrowRight className="w-4 h-4" />
          </span>
        </Link>
      ))}
    </div>
  );
}
