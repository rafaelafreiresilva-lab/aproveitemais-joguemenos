interface WaveDividerProps {
  cor: string;
  direcao?: 'top' | 'bottom';
  className?: string;
}

export default function WaveDivider({ cor, direcao = 'top', className = '' }: WaveDividerProps) {
  return (
    <div className={`w-full overflow-hidden leading-none ${className}`} aria-hidden="true">
      {direcao === 'top' ? (
        <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className="w-full h-[40px] md:h-[60px]">
          <path
            d="M0,40 C240,80 480,0 720,30 C960,60 1200,10 1440,40 L1440,80 L0,80 Z"
            fill={cor}
          />
        </svg>
      ) : (
        <svg viewBox="0 0 1440 80" preserveAspectRatio="none" className="w-full h-[40px] md:h-[60px]">
          <path
            d="M0,40 C240,0 480,60 720,30 C960,0 1200,50 1440,20 L1440,0 L0,0 Z"
            fill={cor}
          />
        </svg>
      )}
    </div>
  );
}
