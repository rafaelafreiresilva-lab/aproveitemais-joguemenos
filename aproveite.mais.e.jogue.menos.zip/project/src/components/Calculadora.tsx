import { useState } from 'react';
import { Share2, RotateCcw, Lightbulb } from 'lucide-react';

interface Resposta {
  pessoas: number;
  comprasSemana: number;
  frequenciaSobra: number;
  estragamSemana: number;
  planejaCardapio: boolean;
}

const frequenciaSobraLabels = ['Raramente', 'Às vezes', 'Frequentemente', 'Quase sempre'];
const estragamLabels = ['Nenhum', '1 item', '2-3 itens', '4+ itens'];

const dicasPorClassificacao: Record<string, string[]> = {
  verde: [
    'Parabéns! Continue compartilhando suas práticas com amigos e vizinhos.',
    'Experimente ajudar alguém que está começando a se organizar melhor.',
    'Que tal participar de uma horta comunitária para ir ainda mais longe?',
  ],
  amarelo: [
    'Comece planejando as refeições da semana antes de ir às compras.',
    'Confira a geladeira antes de comprar para não repetir o que já tem.',
    'Aproveite cascas e talos em receitas simples — você vai se surpreender.',
  ],
  rosa: [
    'Faça uma lista de compras e siga ela. Só isso já reduz muito o desperdício.',
    'Organize a geladeira por data: o que vence primeiro fica na frente.',
    'Congele sobras em porções individuais para não perder nada.',
  ],
};

function calcular(res: Resposta) {
  // Estimativa educativa baseada em médias de referência
  // ~0,5 kg de desperdício por pessoa/dia é a média global (PNUMA)
  // Ajustamos conforme respostas
  const basePessoa = 0.5; // kg/dia
  const fatorSobra = [0.5, 0.8, 1.1, 1.4][res.frequenciaSobra];
  const fatorEstraga = [0.5, 0.9, 1.3, 1.7][res.estragamSemana];
  const fatorCompras = [0.9, 1.0, 1.15, 1.3, 1.5][Math.min(res.comprasSemana, 4)];
  const fatorPlanejamento = res.planejaCardapio ? 0.75 : 1.15;

  const kgDia = basePessoa * res.pessoas * fatorSobra * fatorEstraga * fatorCompras * fatorPlanejamento;
  const kgMes = Math.round(kgDia * 30);
  const reaisMes = Math.round(kgMes * 8); // valor médio estimado por kg

  let classificacao: 'verde' | 'amarelo' | 'rosa';
  if (kgMes <= 10) classificacao = 'verde';
  else if (kgMes <= 25) classificacao = 'amarelo';
  else classificacao = 'rosa';

  const labels = {
    verde: 'Já está no caminho',
    amarelo: 'Dá para melhorar',
    rosa: 'Grande oportunidade',
  };

  return {
    kgMes,
    reaisMes,
    classificacao,
    label: labels[classificacao],
    dicas: dicasPorClassificacao[classificacao],
  };
}

const coresClassificacao = {
  verde: { bg: 'bg-verde-bg', texto: 'text-verde-principal', border: 'border-verde-principal' },
  amarelo: { bg: 'bg-amber-50', texto: 'text-amber-600', border: 'border-amber-500' },
  rosa: { bg: 'bg-rosa-bg', texto: 'text-rosa-principal', border: 'border-rosa-principal' },
};

export default function Calculadora() {
  const [resposta, setResposta] = useState<Resposta>({
    pessoas: 3,
    comprasSemana: 1,
    frequenciaSobra: 1,
    estragamSemana: 1,
    planejaCardapio: false,
  });
  const [resultado, setResultado] = useState<ReturnType<typeof calcular> | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setResultado(calcular(resposta));
  };

  const handleReset = () => {
    setResultado(null);
    setResposta({
      pessoas: 3,
      comprasSemana: 1,
      frequenciaSobra: 1,
      estragamSemana: 1,
      planejaCardapio: false,
    });
  };

  const handleShare = () => {
    if (!resultado) return;
    const texto = `Minha estimativa de desperdício: ${resultado.kgMes} kg/mês (~R$ ${resultado.reaisMes}). Classificação: ${resultado.label}. Calcule a sua também!`;
    const url = encodeURIComponent(window.location.href);
    window.open(`https://wa.me/?text=${encodeURIComponent(texto)} ${url}`, '_blank');
  };

  if (resultado) {
    const cores = coresClassificacao[resultado.classificacao];

    return (
      <div className="bg-white rounded-3xl p-5 md:p-8 shadow-card animate-fade-in">
        <div className={`text-center ${cores.bg} rounded-2xl p-5 md:p-6 mb-5 md:mb-6`}>
          <p className="text-sm text-texto-sec mb-1">Sua classificação</p>
          <p className={`font-titulo font-bold text-xl md:text-2xl ${cores.texto}`}>{resultado.label}</p>
        </div>

        <div className="grid grid-cols-2 gap-3 md:gap-4 mb-5 md:mb-6">
          <div className="bg-verde-bg rounded-2xl p-4 md:p-5 text-center">
            <p className="font-titulo font-bold text-2xl md:text-3xl text-verde-principal">
              {resultado.kgMes}
            </p>
            <p className="text-texto-sec text-sm">kg por mês (estimado)</p>
          </div>
          <div className="bg-rosa-bg rounded-2xl p-4 md:p-5 text-center">
            <p className="font-titulo font-bold text-2xl md:text-3xl text-rosa-principal">
              R$ {resultado.reaisMes}
            </p>
            <p className="text-texto-sec text-sm">por mês (estimado)</p>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-xs text-texto-sec/60 bg-verde-bg/50 rounded-xl px-4 py-3">
            ⚠️ Esta é uma estimativa educativa, não um cálculo exato. Os valores reais podem variar
            conforme seus hábitos e o preço dos alimentos na sua região.
          </p>
        </div>

        <div className="mb-6">
          <h4 className="font-titulo font-semibold text-texto mb-3 flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-rosa-principal" /> Dicas para você
          </h4>
          <ul className="space-y-2">
            {resultado.dicas.map((dica, i) => (
              <li key={i} className="flex items-start gap-2 text-texto-sec text-sm">
                <span className="text-verde-principal font-bold">{i + 1}.</span> {dica}
              </li>
            ))}
          </ul>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleShare}
            className="flex-1 inline-flex items-center justify-center gap-2 bg-verde-principal text-white font-semibold px-6 py-3.5 rounded-full hover:bg-verde-principal/90 transition-all duration-200"
          >
            <Share2 className="w-5 h-5" /> Compartilhar resultado
          </button>
          <button
            onClick={handleReset}
            className="flex-1 inline-flex items-center justify-center gap-2 border-2 border-verde-principal text-verde-principal font-semibold px-6 py-3.5 rounded-full hover:bg-verde-principal hover:text-white transition-all duration-200"
          >
            <RotateCcw className="w-5 h-5" /> Recalcular
          </button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-5 md:p-8 shadow-card">
      {/* Pessoas */}
      <div className="mb-6 md:mb-7">
        <label className="block font-titulo font-semibold text-texto mb-3 text-sm md:text-base">
          Quantas pessoas moram na casa?
        </label>
        <div className="flex items-center gap-4">
          <input
            type="range"
            min={1}
            max={10}
            value={resposta.pessoas}
            onChange={(e) => setResposta({ ...resposta, pessoas: parseInt(e.target.value) })}
            className="flex-1 accent-rosa-principal h-6"
          />
          <span className="font-titulo font-bold text-xl md:text-2xl text-rosa-principal w-12 text-center">
            {resposta.pessoas}
          </span>
        </div>
      </div>

      {/* Compras por semana */}
      <div className="mb-6 md:mb-7">
        <label className="block font-titulo font-semibold text-texto mb-3 text-sm md:text-base">
          Quantas vezes por semana você faz compras?
        </label>
        <div className="flex flex-wrap gap-2">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setResposta({ ...resposta, comprasSemana: n })}
              className={`px-4 py-2.5 rounded-xl font-medium transition-all duration-200 min-w-[48px] min-h-[44px] ${
                resposta.comprasSemana === n
                  ? 'bg-verde-principal text-white'
                  : 'bg-verde-bg text-texto-sec hover:bg-verde-claro/40'
              }`}
            >
              {n}x
            </button>
          ))}
        </div>
      </div>

      {/* Frequência de sobra */}
      <div className="mb-6 md:mb-7">
        <label className="block font-titulo font-semibold text-texto mb-3 text-sm md:text-base">
          Com que frequência sobra comida nas refeições?
        </label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {frequenciaSobraLabels.map((label, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setResposta({ ...resposta, frequenciaSobra: i })}
              className={`px-3 py-3 rounded-xl font-medium text-sm transition-all duration-200 min-h-[48px] ${
                resposta.frequenciaSobra === i
                  ? 'bg-rosa-principal text-white'
                  : 'bg-rosa-bg text-texto-sec hover:bg-rosa-claro/30'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Itens que estragam */}
      <div className="mb-6 md:mb-7">
        <label className="block font-titulo font-semibold text-texto mb-3 text-sm md:text-base">
          Quantos alimentos estragam por semana na sua casa?
        </label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {estragamLabels.map((label, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setResposta({ ...resposta, estragamSemana: i })}
              className={`px-3 py-3 rounded-xl font-medium text-sm transition-all duration-200 min-h-[48px] ${
                resposta.estragamSemana === i
                  ? 'bg-rosa-principal text-white'
                  : 'bg-rosa-bg text-texto-sec hover:bg-rosa-claro/30'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Planejamento de cardápio */}
      <div className="mb-6 md:mb-7">
        <label className="block font-titulo font-semibold text-texto mb-3 text-sm md:text-base">
          Você faz planejamento de cardápio da semana?
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="button"
            onClick={() => setResposta({ ...resposta, planejaCardapio: true })}
            className={`flex-1 px-4 py-3.5 rounded-xl font-medium transition-all duration-200 min-h-[48px] ${
              resposta.planejaCardapio
                ? 'bg-verde-principal text-white'
                : 'bg-verde-bg text-texto-sec hover:bg-verde-claro/40'
            }`}
          >
            Sim, planejo
          </button>
          <button
            type="button"
            onClick={() => setResposta({ ...resposta, planejaCardapio: false })}
            className={`flex-1 px-4 py-3.5 rounded-xl font-medium transition-all duration-200 min-h-[48px] ${
              !resposta.planejaCardapio
                ? 'bg-rosa-principal text-white'
                : 'bg-rosa-bg text-texto-sec hover:bg-rosa-claro/30'
            }`}
          >
            Não, costumo não planejar
          </button>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-rosa-principal text-white font-bold px-6 py-4 rounded-full hover:bg-rosa-principal/90 transition-all duration-200 shadow-md hover:shadow-lg text-base md:text-lg min-h-[52px]"
      >
        Ver meu resultado
      </button>
    </form>
  );
}
