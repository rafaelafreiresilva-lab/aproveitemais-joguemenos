interface SectionHeadingProps {
  eyebrow?: string;
  titulo: string;
  descricao?: string;
  centro?: boolean;
}

export default function SectionHeading({
  eyebrow,
  titulo,
  descricao,
  centro = true,
}: SectionHeadingProps) {
  return (
    <div className={`max-w-2xl px-5 md:px-0 ${centro ? 'mx-auto text-center' : ''}`}>
      {eyebrow && (
        <span className="inline-block text-rosa-principal font-semibold text-sm uppercase tracking-wide mb-2">
          {eyebrow}
        </span>
      )}
      <h2 className="font-titulo font-bold text-2xl md:text-3xl lg:text-4xl text-texto leading-tight">
        {titulo}
      </h2>
      {descricao && (
        <p className="mt-3 text-texto-sec text-base md:text-lg leading-relaxed">{descricao}</p>
      )}
    </div>
  );
}
