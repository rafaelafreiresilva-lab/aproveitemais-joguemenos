import { Link } from 'react-router-dom';
import { Leaf, Heart, Instagram, Facebook, Youtube, MessageCircle } from 'lucide-react';
import { fontesDados } from '@/data/dados';

const linksRapidos = [
  { to: '/', label: 'Home' },
  { to: '/como-ajudar', label: 'Como ajudar' },
  { to: '/entenda-e-calcule', label: 'Entenda e calcule' },
  { to: '/dados', label: 'Dados' },
  { to: '/desafios', label: 'Desafios semanais' },
  { to: '/participe', label: 'Participe' },
];

const redes = [
  { icone: Instagram, label: 'Instagram', href: '#' },
  { icone: Facebook, label: 'Facebook', href: '#' },
  { icone: Youtube, label: 'YouTube', href: '#' },
  { icone: MessageCircle, label: 'WhatsApp', href: '#' },
];

export default function Footer() {
  return (
    <footer className="bg-verde-principal text-white">
      <div className="max-w-7xl mx-auto px-5 md:px-6 py-10 md:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 md:gap-12">
          {/* Logo e slogan */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="flex items-center justify-center w-10 h-10 rounded-2xl bg-white/15">
                <Leaf className="w-5 h-5 text-white" />
              </span>
              <span className="font-titulo font-semibold text-lg">
                Aproveite Mais
              </span>
            </div>
            <p className="text-verde-claro text-sm leading-relaxed max-w-xs">
              Aproveite mais, jogue menos. Um movimento pela redução do desperdício de alimentos.
            </p>
            <div className="flex items-center gap-3 mt-5">
              {redes.map((rede) => (
                <a
                  key={rede.label}
                  href={rede.href}
                  aria-label={rede.label}
                  className="flex items-center justify-center w-10 h-10 rounded-xl bg-white/15 hover:bg-rosa-principal transition-colors duration-200"
                >
                  <rede.icone className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Links rápidos */}
          <div>
            <h3 className="font-titulo font-semibold text-base mb-4">Links rápidos</h3>
            <ul className="space-y-2.5">
              {linksRapidos.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-verde-claro hover:text-white transition-colors text-sm"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Fontes */}
          <div>
            <h3 className="font-titulo font-semibold text-base mb-4">Fontes dos dados</h3>
            <ul className="space-y-2.5">
              {fontesDados.map((fonte, i) => (
                <li key={i} className="text-verde-claro text-xs leading-relaxed">
                  {fonte}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/20 flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-verde-claro text-sm flex items-center gap-1.5">
            Feito pela comunidade, para a comunidade <Heart className="w-3.5 h-3.5 text-rosa-claro" />
          </p>
          <p className="text-verde-claro/70 text-xs">
            © {new Date().getFullYear()} Aproveite Mais
          </p>
        </div>
      </div>
    </footer>
  );
}
