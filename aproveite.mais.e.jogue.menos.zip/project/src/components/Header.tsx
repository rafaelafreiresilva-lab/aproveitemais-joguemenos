import { useEffect, useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { Menu, X, Leaf, Heart } from 'lucide-react';

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/como-ajudar', label: 'Como ajudar' },
  { to: '/entenda-e-calcule', label: 'Entenda e calcule' },
  { to: '/dados', label: 'Dados' },
  { to: '/desafios', label: 'Desafios semanais' },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `relative font-medium transition-colors duration-200 px-2 py-1 ${
      isActive
        ? 'text-verde-principal'
        : 'text-texto-sec hover:text-verde-principal'
    }`;

  const linkUnderline = ({ isActive }: { isActive: boolean }) =>
    isActive
      ? 'after:absolute after:bottom-0 after:left-0 after:w-full after:h-0.5 after:bg-rosa-principal after:rounded-full'
      : '';

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-bg/95 backdrop-blur-md shadow-card'
          : 'bg-bg/80 backdrop-blur-sm'
      }`}
    >
      <nav className="max-w-7xl mx-auto px-4 md:px-6" aria-label="Navegação principal">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 shrink-0" aria-label="Página inicial">
            <span className="flex items-center justify-center w-9 h-9 md:w-10 md:h-10 rounded-2xl bg-verde-bg">
              <Leaf className="w-5 h-5 text-verde-principal" />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="font-titulo font-semibold text-texto text-base md:text-lg">
                Aproveite Mais
              </span>
              <span className="flex items-center gap-1 text-[10px] md:text-xs text-rosa-principal font-medium">
                <Heart className="w-3 h-3" /> Jogue menos
              </span>
            </span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden lg:flex items-center gap-5">
            {navLinks.map((link) => (
              <NavLink key={link.to} to={link.to} className={linkClass} end={link.to === '/'}>
                {({ isActive }) => (
                  <span className={linkUnderline({ isActive })}>{link.label}</span>
                )}
              </NavLink>
            ))}
          </div>

          {/* Desktop CTA */}
          <Link
            to="/participe"
            className="hidden lg:inline-flex items-center gap-2 bg-rosa-principal text-white font-semibold px-5 py-2.5 rounded-full hover:bg-rosa-principal/90 transition-all duration-200 shadow-sm hover:shadow-md hover:-translate-y-0.5"
          >
            Participe
          </Link>

          {/* Mobile toggle */}
          <button
            className="lg:hidden p-2.5 -mr-2 rounded-xl text-verde-principal hover:bg-verde-bg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
            onClick={() => setOpen(true)}
            aria-label="Abrir menu"
            aria-expanded={open}
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-50 animate-fade-in">
          <div className="absolute inset-0 bg-texto/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-0 bottom-0 w-full max-w-xs bg-bg shadow-2xl animate-slide-down flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-verde-bg">
              <span className="font-titulo font-semibold text-texto">Menu</span>
              <button
                className="p-2.5 rounded-xl text-verde-principal hover:bg-verde-bg transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
                onClick={() => setOpen(false)}
                aria-label="Fechar menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="flex flex-col gap-2 p-4 flex-1">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === '/'}
                  onClick={() => setOpen(false)}
                  className={({ isActive }) =>
                    `px-4 py-4 rounded-2xl font-medium text-lg transition-colors ${
                      isActive
                        ? 'bg-verde-bg text-verde-principal'
                        : 'text-texto hover:bg-verde-bg/60'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <Link
                to="/participe"
                onClick={() => setOpen(false)}
                className="mt-4 text-center bg-rosa-principal text-white font-semibold px-5 py-3.5 rounded-full text-lg shadow-sm"
              >
                Participe
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
