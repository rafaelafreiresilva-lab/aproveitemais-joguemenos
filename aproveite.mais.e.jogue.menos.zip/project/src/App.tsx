import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ScrollToTop from '@/components/ScrollToTop';
import Home from '@/pages/Home';
import ComoAjudar from '@/pages/ComoAjudar';
import EntendaCalcule from '@/pages/EntendaCalcule';
import Dados from '@/pages/Dados';
import Desafios from '@/pages/Desafios';
import Participe from '@/pages/Participe';

function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/como-ajudar" element={<ComoAjudar />} />
            <Route path="/entenda-e-calcule" element={<EntendaCalcule />} />
            <Route path="/dados" element={<Dados />} />
            <Route path="/desafios" element={<Desafios />} />
            <Route path="/participe" element={<Participe />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
